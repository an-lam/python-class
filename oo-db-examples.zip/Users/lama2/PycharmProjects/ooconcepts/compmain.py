# compmain.py

from computersystem import ComputerSystem


computer1 = ComputerSystem("87.90.11.0", "San Jose", "Dell")

print(computer1.ip_addr)
print("Getting osname:")
print(computer1.osname)

print("\n Setting ip_addr:")
computer1.ip_addr = "1.2.3.4"

print("Getting ip_addr:")
print(computer1.ip_addr)

# Setting osname indirectly by installing OS
computer1.install_os("Windows 10", "windows.zip")
#computer1.osname = "Linux"          # Error, no setter method for osname
print(computer1.osname)

print(computer1._version)

computer2 = ComputerSystem("4.3.2.1", "Santa Clara")
# Calling setter method
print("\n Setting manufacturer:")
computer2.manufacturer = "HP"

# Calling getter method
print(computer2.manufacturer)